#include <stdlib.h>
#include "analyzer.h"

struct ImageInfo * analyze_images_in_directory(int thread_limit, const char * directory, int * images_analyzed) {
	*images_analyzed = 0;
	return NULL;
}


