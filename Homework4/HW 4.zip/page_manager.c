#include "page_manager.h"

static memory_config config;

void initialize_page_manager(memory_config mc) {
	config = mc;

	/* Other initialization work here. */
}

access_result access_memory(unsigned int pid, unsigned int virtual_address) {
	access_result result;

	/* Do work here. */

	return result;
}

