#ifdef __APPLE__
#include <sys/time.h>
#define STOPWATCH_TYPE struct timeval
#define STOPWATCH_CLICK(x) gettimeofday(&x, NULL)
#else
#define _POSIX_C_SOURCE 199309
#include <time.h>
#define STOPWATCH_TYPE struct timespec
#define STOPWATCH_CLICK(x) clock_gettime(CLOCK_REALTIME, &x)
#endif
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>


long ms_diff(STOPWATCH_TYPE start, STOPWATCH_TYPE stop);


int * multithreaded_matrix_product(const int A[], const int B[], int r, int s, int t) {
	return NULL;
}

// Creates an r-by-s matrix with random elements in the range [-5, 5].
int * create_random_matrix(int r, int s) {
	int size = r * s;
	int * matrix = (int *)malloc(size * sizeof(int));
	int i;
	for (i = 0; i < size; i++)
		matrix[i] = rand() % 11 - 5;
	return matrix;
}

int main(int argc, char* argv[]) {
	srand(time(NULL));

	const int r = 1000;
	const int s = 2000;
	const int t = 1000;
	int * A = create_random_matrix(r, s);
	int * B = create_random_matrix(s, t);
	STOPWATCH_TYPE start;
	STOPWATCH_CLICK(start);
	int * C = multithreaded_matrix_product(A, B, r, s, t);
	STOPWATCH_TYPE stop;
	STOPWATCH_CLICK(stop);
	printf("%ld ms elapsed.\n", ms_diff(start, stop));
	free(A);
	free(B);
	free(C);

	return EXIT_SUCCESS;
}

#ifdef __APPLE__
long ms_diff(struct timeval start, struct timeval stop) {
	return 1000L * (stop.tv_sec - start.tv_sec) + (stop.tv_usec - start.tv_usec) / 1000;
}
#else
long ms_diff(struct timespec start, struct timespec stop) {
	return 1000L * (stop.tv_sec - start.tv_sec) + (stop.tv_nsec - start.tv_nsec) / 1000000;
}
#endif
